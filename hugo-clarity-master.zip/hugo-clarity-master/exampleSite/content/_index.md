+++
author = "Hugo Authors"
description = "A theme based on VMware's Clarity Design System for publishing technical blogs with Hugo." # set your site's description here. will be use for home page content meta tags (seo).
+++
